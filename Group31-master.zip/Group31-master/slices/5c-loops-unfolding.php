<?php

    $a = b('user');
    while (true) {
        if($x == $a){
            $c = s($a, 1);
            break;
        }
        ++$x;
    }
    $q = z($c);

    // tip: the number of steps that may lead to the encoding of a vulnerability or sanitization may depend on runtime information.

?>