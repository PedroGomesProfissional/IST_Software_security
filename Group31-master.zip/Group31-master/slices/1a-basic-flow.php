<?php

    $a = "";
    $b = c();
    d($a);
    e($b);

    // tip: variables might be tainted or not before they reach a sink
?>