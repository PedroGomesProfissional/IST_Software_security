<?php

    $a = b();
    if ($g == 0){
        $a = "";
        $d = t();
    } else {
        $a = c($a, $d);
    }
    e($a, $d);

    // tip: different control paths, via branching, might encode or not different vulnerablities.

?>