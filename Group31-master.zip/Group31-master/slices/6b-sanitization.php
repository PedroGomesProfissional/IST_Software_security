<?php

    $a = b();
    $b = c("booboo");
    $d = e($a, $b);

    // tip: relative order of sources, sanitizers and sinks, matters

?>