import json
import sys
import os

# Get the file paths from the command line arguments
sliceAST_path = sys.argv[1]
pattern_path = sys.argv[2]

# Read in the slice AST json file
with open(sliceAST_path, 'r') as f:
    sliceAST = json.load(f)

# Read in the second JSON file
with open(pattern_path, 'r') as f:
    pattern_path = json.load(f)

# List that contains multiple possible ASTs
list_of_asts = []

# List that contains all node lists
# Ex: [["$a", "c"], ["$a"]]
node_list = []

# List that contains dictionaries representing graph edges
# Ex: [{"$a": ["b", "c"]}, ...]
graph_list = []

# List containing all uninitiated variables lists
uninitiated_list = []


# Used to eliminate branching from original AST
# by creating multiple ASTs without branches
# processed: lines of AST that have already been processed
# to_process: lines of AST that need to be processed
def generate_asts(processed, to_process):
    while len(to_process) != 0:
        if to_process[0]['nodeType'] == 'Stmt_If':
            else_stmt = []
            if_stmt = to_process[0]['stmts'].copy()
            if to_process[0]['else'] != None:
                else_stmt = to_process[0]['else']['stmts'].copy()
            to_process.pop(0)
            generate_asts(processed.copy(), if_stmt + to_process.copy())
            if len(else_stmt) != 0:
                to_process = else_stmt + to_process
        elif to_process[0]['nodeType'] == 'Stmt_While':
            while_stmt = to_process[0]['stmts'].copy()
            to_process.pop(0)
            generate_asts(processed.copy(), while_stmt + to_process.copy())
        else:
            processed.append(to_process[0])
            to_process.pop(0)

    list_of_asts.append(processed)


def generate_graphs():
    # List that contains all nodes as strings
    # Ex: "$a", "c"
    nodes = []
    # Dictionary that contains arches represented as lists
    # Ex: ["$a": ["b", "c"] ]
    graph = {}
    # List of nodes that are uninitiated variables
    uninitiated_vars = []

    # Used to recursively explore nodes that contain multiple parts
    # node: node to explore
    # name: name of the function
    def explore_args(node, name):
        if node['nodeType'] == 'Arg':
            explore_args(node['value'], name)
        elif node['nodeType'] == 'Expr_BinaryOp_Concat' or node['nodeType'] == 'Expr_BinaryOp_Plus':
            explore_args(node['left'], name)
            explore_args(node['right'], name)
        elif node['nodeType'] == 'Expr_Variable':
            variable = '$' + str(node['name'])
            if variable not in nodes:
                if variable not in uninitiated_vars:
                    uninitiated_vars.append(variable)
                nodes.append(variable)
                graph[variable] = []
            if name not in graph[variable]:
                graph[variable].append(name)
        elif node['nodeType'] == 'Expr_FuncCall':
            function = str(node['name']['parts'][0])
            if function not in nodes:
                nodes.append(function)
                graph[function] = []
            if name not in graph[function]:
                graph[function].append(name)
            for val in node['args']:
                explore_args(val, function)

    # Iterating through every possible AST
    for ast in list_of_asts:
        # Iterating through every line in the AST
        for line in ast:

            # Discard certain nodeTypes
            if line['nodeType'] != 'Stmt_Expression':
                continue

            # If we have an assignment
            if line['expr']['nodeType'] == 'Expr_Assign':

                # Case where we have a variable on the left
                if line['expr']['var']['nodeType'] == 'Expr_Variable':
                    left = '$' + str(line['expr']['var']['name'])

                    if left not in nodes:
                        nodes.append(left)
                        graph[left] = []

                    # Case where there is a variable on the right
                    if line['expr']['expr']['nodeType'] == 'Expr_Variable':
                        right = '$' + str(line['expr']['expr']['name'])

                        if right not in nodes:
                            # If the right is not in nodes it has not been assigned
                            if right not in uninitiated_vars:
                                uninitiated_vars.append(right)
                            nodes.append(right)
                            graph[right] = []
                        if left not in graph[right]:
                            graph[right].append(left)


                    # Case where there is a function on the right
                    elif line['expr']['expr']['nodeType'] == 'Expr_FuncCall':
                        right = str(line['expr']['expr']['name']['parts'][0])

                        if right not in nodes:
                            nodes.append(right)
                            graph[right] = []
                        if left not in graph[right]:
                            graph[right].append(left)

                        # explore the functions arguments
                        for node in line['expr']['expr']['args']:
                            explore_args(node, right)

                    # Case where there is a binary operation on the right
                    elif line['expr']['expr']['nodeType'] == 'Expr_BinaryOp_Plus':
                        explore_args(line['expr']['expr'], left)

            # If we have a function call
            elif line['expr']['nodeType'] == 'Expr_FuncCall':
                funcName = str(line['expr']['name']['parts'][0])

                if funcName not in nodes:
                    nodes.append(funcName)
                    graph[funcName] = []

                # explore the functions arguments
                for node in line['expr']['args']:
                    explore_args(node, funcName)

            # If we have an increase (x++)
            if line['expr']['nodeType'] == 'Expr_PreInc':
                varName = '$' + str(line['expr']['var']['name'])

                if varName not in nodes:
                    nodes.append(varName)
                    graph[varName] = []

        node_list.append(nodes)
        graph_list.append(graph)
        uninitiated_list.append(uninitiated_vars)

        nodes = []
        graph = {}
        uninitiated_vars = []


# Generating all the possible ASTs
generate_asts([], sliceAST.copy())

# for ast in list_of_asts:
#     print("AST: \n")
#     for line in ast:
#         print(line)
#     print("\n")

# Generating graphs
generate_graphs()
#
# print(node_list)
# print(graph_list)
# print(uninitiated_list)


class dd_list(dict):
    def __missing__(self, k):
        r = self[k] = []
        return r


"""def list_to_graph(lst_graph):
    d_as_graph = dd_list()
    for arcs in lst_graph:
        #print("arcs", arcs)
        for arc in arcs:
            #print(el)
            d_as_graph[arc[0]].append(arc[1])

    #print ("Graph", d_as_graph)
    return d_as_graph

#print(list_to_graph(arcs_lst))"""

vuln_lst = []
for vuln in pattern_path:
    # print(vuln)
    vuln_lst += [[[vuln['vulnerability']], vuln['sources'], vuln['sanitizers'], vuln['sinks'], vuln['implicit']]]


# print(vuln_lst)

def join_new_srcs_vuln_lst(vuln_lst, new_src_lst):
    # print("vuln_lst", vuln_lst, "new_src_lst", new_src_lst)

    new_src_vuln_lst = [];
    src_vuln_lst = []
    for src in new_src_lst:
        for vuln in vuln_lst:
            # print(vuln)
            src_vuln_lst += [[vuln[0], [src], vuln[2], vuln[3]]]

    # print("new_src_vuln_lst", new_src_vuln_lst)

    new_src_vuln_lst = vuln_lst + src_vuln_lst
    # print("new_src_vuln_lst", new_src_vuln_lst)
    return new_src_vuln_lst


# print(join_new_srcs_vuln_lst(vuln_lst, uninitiated_list[0]))

def find_all_paths(graph, start, end, path=[]):
    path = path + [start]
    if start == end:
        return [path]
    paths = []
    newpaths = []
    for node in graph[start]:
        if path.count(node) < 2:
            newpaths = find_all_paths(graph, node, end, path)
        for newpath in newpaths:
            paths.append(newpath)

    return paths


# graph = list_to_graph(arcs_lst)
# print(graph)
# print("all_paths", find_all_paths(graph,'$a',"d"))


def find_all_src_sinks(all_srcs_vuln_lst, node_lst):
    # print(vuln_lst[0][1], vuln_lst[0][3])

    # print("all_srcs_vuln_lst", all_srcs_vuln_lst)

    all_vuln_lst = []
    for vuln in all_srcs_vuln_lst:
        # print("vuln", vuln)
        for src in vuln[1]:
            # print("src", src)
            for sink in vuln[3]:
                # print(src, sink)
                if vuln[2] == []:
                    # print("src", src, "sink", sink)
                    if src != sink and src in node_lst and sink in node_lst:
                        all_vuln_lst += [[vuln[0], src, [], sink]]

                else:
                    for sanit in vuln[2]:
                        # print("src", src, "sink", sink)
                        # print(src, sanit, sink)
                        if src != sink and src in node_lst and sink in node_lst:
                            all_vuln_lst += [[vuln[0], src, sanit, sink]]

    # print("all_vuln_lst", all_vuln_lst )
    return all_vuln_lst


# print(find_all_src_sinks(join_new_srcs_vuln_lst(vuln_lst, uninitiated_list[0]), node_list[0] ))


def find_all_vuln_paths(graph, all_src_sink_lst):
    # print("all_src_sink_lst", all_src_sink_lst)
    all_vuln_paths_lst = []

    for src_sink in all_src_sink_lst:
        # print("all_paths",find_all_paths(graph, src_sink[1], src_sink[2]))
        # print(src_sink)
        all_vuln_paths_lst += [[src_sink[0], find_all_paths(graph, src_sink[1], src_sink[3])]]

    # print("all_vuln_paths_lst", all_vuln_paths_lst)
    return all_vuln_paths_lst


"""print(find_all_vuln_paths(graph_list[0],
                          find_all_src_sinks(join_new_srcs_vuln_lst(vuln_lst,
                                                                    uninitiated_list[0]), node_list[0])))
"""

def is_src_sanit_sink_in_path(all_src_sink_paths, all_vuln_lst):
    # print(all_src_sink_paths)

    d = dd_list()
    for vuln in vuln_lst:
        # print("arcs", arcs)
        d[vuln[0][0]].append((vuln[2]))

    # print(d)
    # print(d['B'][0])
    # print("all_vuln_lst", all_vuln_lst)

    #print('\n')
    lst_src_sanit_sink_in_path = []

    for src_sink_path in all_src_sink_paths:
        # print("src_sink_path", src_sink_path)

        for vuln in all_vuln_lst:

            for paths in src_sink_path:

                for path in paths:

                    # verifica se a path tem a msm src e sink
                    if (path[0] == vuln[1] and path[-1] == vuln[-1]):

                        for el in d:

                            # print(list(set(path) & set(d[el][0])))
                            lst_set = list(set(path) & set(d[el][0]))
                            # print(vuln[0], [el])
                            if len(lst_set) == 0 and vuln[0] == [el]:
                                lst_src_sanit_sink_in_path += [[vuln[0], path[0], path[-1], "yes", []]]

                            if (len(lst_set) > 0) and vuln[0] == [el]:
                                lst_src_sanit_sink_in_path += [[vuln[0], path[0], path[-1], "no", [lst_set]]]

    lst_src_sanit_sink_in_path_dup = []
    # lst_src_sanit_sink_in_path_dup = list()

    [lst_src_sanit_sink_in_path_dup.append(item) for item in lst_src_sanit_sink_in_path if
     item not in lst_src_sanit_sink_in_path_dup]

    # print("lst_src_sanit_sink_in_path", lst_src_sanit_sink_in_path)
    #print("lst_src_sanit_sink_in_path", lst_src_sanit_sink_in_path_dup, '\n')
    return lst_src_sanit_sink_in_path_dup
l= []
for i in range(len(node_list)):
    aux = is_src_sanit_sink_in_path(find_all_vuln_paths(graph_list[i],
            find_all_src_sinks(
                join_new_srcs_vuln_lst(vuln_lst, uninitiated_list[i]),
                node_list[i])),
            find_all_src_sinks(
                join_new_srcs_vuln_lst(vuln_lst,uninitiated_list[i]),
                node_list[i]))
    # print(aux)
    for i in aux:
        if i not in l:
            l += [i]
    # print(is_src_sanit_sink_in_path(find_all_vuln_paths(graph_list[i],
    #         find_all_src_sinks(
    #             join_new_srcs_vuln_lst(vuln_lst, uninitiated_list[i]),
    #             node_list[i])),
    #         find_all_src_sinks(
    #             join_new_srcs_vuln_lst(vuln_lst,uninitiated_list[i]),
    #             node_list[i])))

# print("lst final", l)


# output_lst = ["vulnerabilidade_name="A", "source="$a", "sink="d", "unsanitized_flows[yes/no]=yes",  sanitized flows["S"]]
""" "vulnerability": "A",
        "source": "c",
        "sink": "e",
        "unsanitized flows": "yes",
        "sanitized flows": [["s"]] """


##### Third person #####
# Find out how implicit flow impacts the tool
# Generate output file in correct folder

def format_lst(lst):
    new_lst = []
    for i in lst:
        new_lst.append([i[0][0], i[1], i[2], i[3], i[4]])
    return new_lst


def transform_lst(lst):
    new_lst = []
    for i in lst:
        if len(new_lst) == 0:
            # if len(i[4]) == 0:
            #     i[4] = [i[4]]
            new_lst.append(i)
        elif i[0] == new_lst[len(new_lst) - 1][0] and i[1] == new_lst[len(new_lst) - 1][1] and i[2] == \
                new_lst[len(new_lst) - 1][2]:
            if i[3] != new_lst[len(new_lst) - 1][3]:
                new_lst[len(new_lst) - 1][3] = 'yes'
            if len(i[4]) > 0:
                # print(new_lst[len(new_lst) - 1])
                # print(new_lst[len(new_lst) - 1][4])
                new_lst[len(new_lst) - 1][4].append(i[4][0])
        else:
            new_lst.append(i)      
    return new_lst

# Change "b" to whatever name the var has
# print(l)
a = transform_lst(format_lst(l))

json_lst = []

for i in a:
    json_dict = dict.fromkeys(["vulnerability", "source", "sink", "unsanitized flows", "sanitized flows"])
    json_dict["vulnerability"] = i[0]
    json_dict["source"] = i[1]
    json_dict["sink"] = i[2]
    json_dict["unsanitized flows"] = i[3]
    json_dict["sanitized flows"] = i[4]

    json_lst = json_lst + [json_dict]

# print(json_lst)

json_object = json.dumps(json_lst, indent=4)

with open("output/" + os.path.basename(sliceAST_path)[:-5] + ".output.json", "w") as outfile:
    outfile.write(json_object)
# Test tool
