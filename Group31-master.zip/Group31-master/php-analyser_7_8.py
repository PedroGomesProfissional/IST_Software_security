import json
import sys

# Get the file paths from the command line arguments
sliceAST_path = sys.argv[1]
pattern_path = sys.argv[2]

# Read in the slice AST json file
with open(sliceAST_path, 'r') as f:
    sliceAST = json.load(f)

# Read in the second JSON file
with open(pattern_path, 'r') as f:
    pattern_path = json.load(f)

# List that contains multiple possible ASTs
list_of_asts = []

# List that contains all node lists
# Ex: [["$a", "c"], ["$a"]]
node_list = []

# List that contains dictionaries representing graph edges
# Ex: [{"$a": ["b", "c"]}, ...]
graph_list = []

# List containing all uninitiated variables lists
uninitiated_list = []

nodes = []
# Dictionary that contains arches represented as lists
# Ex: ["$a": ["b", "c"] ]
graph = {}
# List of nodes that are uninitiated variables
uninitiated_nodes = []


# Used to eliminate branching from original AST
# by creating multiple ASTs without branches
# processed: lines of AST that have already been processed
# to_process: lines of AST that need to be processed
def generate_asts(processed, to_process):
    while len(to_process) != 0:
        if to_process[0]['nodeType'] == 'Stmt_If':
            else_stmt = []
            if_stmt = to_process[0]['stmts'].copy()
            if to_process[0]['else'] != None:
                else_stmt = to_process[0]['else']['stmts'].copy()
            to_process.pop(0)
            generate_asts(processed.copy(), if_stmt + to_process.copy())
            if len(else_stmt) != 0:
                to_process = else_stmt + to_process
        elif to_process[0]['nodeType'] == 'Stmt_While':
            while_stmt = to_process[0]['stmts'].copy()
            to_process.pop(0)
            generate_asts(processed.copy(), while_stmt + to_process.copy())
        else:
            processed.append(to_process[0])
            to_process.pop(0)

    list_of_asts.append(processed)


def generate_graphs():
    # List that contains all nodes as strings
    # Ex: "$a", "c"
    nodes = []
    # Dictionary that contains arches represented as lists
    # Ex: ["$a": ["b", "c"] ]
    graph = {}
    # List of nodes that are uninitiated variables
    uninitiated_vars = []

    # Used to recursively explore nodes that contain multiple parts
    # node: node to explore
    # name: name of the function
    def explore_args(node, name):
        if node['nodeType'] == 'Arg':
            explore_args(node['value'], name)
        elif node['nodeType'] == 'Expr_BinaryOp_Concat' or node['nodeType'] == 'Expr_BinaryOp_Plus':
            explore_args(node['left'], name)
            explore_args(node['right'], name)
        elif node['nodeType'] == 'Expr_Variable':
            variable = '$' + str(node['name'])
            if variable not in nodes:
                if variable not in uninitiated_vars:
                    uninitiated_vars.append(variable)
                nodes.append(variable)
                graph[variable] = []
            if name not in graph[variable]:
                graph[variable].append(name)
        elif node['nodeType'] == 'Expr_FuncCall':
            function = str(node['name']['parts'][0])
            if function not in nodes:
                nodes.append(function)
                graph[function] = []
            if name not in graph[function]:
                graph[function].append(name)
            for val in node['args']:
                explore_args(val, function)

    # Iterating through every possible AST
    for ast in list_of_asts:
        # Iterating through every line in the AST
        for line in ast:

            # Discard certain nodeTypes
            if line['nodeType'] != 'Stmt_Expression':
                continue

            # If we have an assignment
            if line['expr']['nodeType'] == 'Expr_Assign':

                # Case where we have a variable on the left
                if line['expr']['var']['nodeType'] == 'Expr_Variable':
                    left = '$' + str(line['expr']['var']['name'])

                    if left not in nodes:
                        nodes.append(left)
                        graph[left] = []

                    # Case where there is a variable on the right
                    if line['expr']['expr']['nodeType'] == 'Expr_Variable':
                        right = '$' + str(line['expr']['expr']['name'])

                        if right not in nodes:
                            # If the right is not in nodes it has not been assigned
                            if right not in uninitiated_vars:
                                uninitiated_vars.append(right)
                            nodes.append(right)
                            graph[right] = []
                        if left not in graph[right]:
                            graph[right].append(left)


                    # Case where there is a function on the right
                    elif line['expr']['expr']['nodeType'] == 'Expr_FuncCall':
                        right = str(line['expr']['expr']['name']['parts'][0])

                        if right not in nodes:
                            nodes.append(right)
                            graph[right] = []
                        if left not in graph[right]:
                            graph[right].append(left)

                        # explore the functions arguments
                        for node in line['expr']['expr']['args']:
                            explore_args(node, right)

                    # Case where there is a binary operation on the right
                    elif line['expr']['expr']['nodeType'] == 'Expr_BinaryOp_Plus':
                        explore_args(line['expr']['expr'], left)

            # If we have a function call
            elif line['expr']['nodeType'] == 'Expr_FuncCall':
                funcName = str(line['expr']['name']['parts'][0])

                if funcName not in nodes:
                    nodes.append(funcName)
                    graph[funcName] = []

                # explore the functions arguments
                for node in line['expr']['args']:
                    explore_args(node, funcName)

            # If we have an increase (x++)
            if line['expr']['nodeType'] == 'Expr_PreInc':
                varName = '$' + str(line['expr']['var']['name'])

                if varName not in nodes:
                    nodes.append(varName)
                    graph[varName] = []

        node_list.append(nodes)
        graph_list.append(graph)
        uninitiated_list.append(uninitiated_vars)

        nodes = []
        graph = {}
        uninitiated_vars = []


# Generating all the possible ASTs
generate_asts([], sliceAST.copy())

# for ast in list_of_asts:
#     print("AST: \n")
#     for line in ast:
#         print(line)
#     print("\n")

# Generating graphs
generate_graphs()
#
# print(node_list)
# print(graph_list)
# print(uninitiated_list)


vuln_lst = []
for vuln in pattern_path:
    # print(vuln)
    vuln_lst += [[[vuln['vulnerability']], vuln['sources'], vuln['sanitizers'], vuln['sinks'], vuln['implicit']]]

# print(vuln_lst)

def get_vars_inside_cond():
    lst_inside_cond = []

    for node in sliceAST:
        if node['nodeType'] == 'Stmt_If':
            if node['cond']['nodeType'] == 'Expr_BinaryOp_Equal':
                if node['cond']['left']['nodeType'] == 'Expr_Variable':
                    #print("===========", node['cond']['left']['name'])
                    lst_inside_cond.append("$" + node['cond']['left']['name'])
                    #print("lst_inside_cond = ", lst_inside_cond)

                if node['cond']['right']['nodeType'] == 'Expr_Variable':
                    #print("===========", node['cond']['right']['name'])
                    lst_inside_cond.append("$" + node['cond']['right']['name'])
                    #print("lst_inside_cond = ", lst_inside_cond)
                    #print(node)

        if node['nodeType'] == 'Stmt_While':
            if node['cond']['nodeType'] == 'Expr_BinaryOp_Equal':
                if node['cond']['left']['nodeType'] == 'Expr_Variable':
                    #print("===========", node['cond']['left']['name'])
                    lst_inside_cond.append("$" + node['cond']['left']['name'])
                    #print("lst_inside_cond = ", lst_inside_cond)

                if node['cond']['right']['nodeType'] == 'Expr_Variable':
                    #print("===========", node['cond']['right']['name'])
                    lst_inside_cond.append("$" + node['cond']['right']['name'])
                    #print("lst_inside_cond = ", lst_inside_cond)
                    #print(node)


    #print("lst_inside_cond", lst_inside_cond)
    return lst_inside_cond

get_vars_inside_cond()

lst_before_cond = []
for line in sliceAST:

    if line['nodeType'] != 'Stmt_If':
        # print(line, '\n')
        # Discard certain nodeTypes
        if line['nodeType'] != 'Stmt_Expression':
            continue

        # If we have an assignment
        if line['expr']['nodeType'] == 'Expr_Assign':

            # Case where we have a variable on the left
            if line['expr']['var']['nodeType'] == 'Expr_Variable':
                left = '$' + str(line['expr']['var']['name'])
                lst_before_cond += [left]

                # Case where there is a variable on the right
                if line['expr']['expr']['nodeType'] == 'Expr_Variable':
                    right = '$' + str(line['expr']['expr']['name'])
                    lst_before_cond += [right]

                # Case where there is a function on the right
                elif line['expr']['expr']['nodeType'] == 'Expr_FuncCall':
                    right = str(line['expr']['expr']['name']['parts'][0])
                    lst_before_cond += [right]
        # If we have a function call
        elif line['expr']['nodeType'] == 'Expr_FuncCall':
            funcName = str(line['expr']['name']['parts'][0])
            lst_before_cond += [funcName]

        # If we have an increase (x++)
        if line['expr']['nodeType'] == 'Expr_PreInc':
            varName = '$' + str(line['expr']['var']['name'])
            lst_before_cond += [varName]

    elif line['nodeType'] == 'Stmt_If':
        lst_before_cond += ["||"]

#print("lst_before_cond", lst_before_cond)


lst_global = []

def explore_args_2(node, name):
    global lst_global
    if node['nodeType'] == 'Arg':
        explore_args_2(node['value'], name)
    elif node['nodeType'] == 'Expr_BinaryOp_Concat' or node['nodeType'] == 'Expr_BinaryOp_Plus':
        explore_args_2(node['left'], name)
        explore_args_2(node['right'], name)
    elif node['nodeType'] == 'Expr_Variable':
        variable = '$'+str(node['name'])
        lst_global += [variable]

    elif node['nodeType'] == 'Expr_FuncCall':
        function = str(node['name']['parts'][0])
        lst_global += [function]
        for val in node['args']:
            explore_args_2(val, function)



def find_nodes(line, lst_put):
        global lst_global

        if line['nodeType'] == 'Stmt_Expression':

            # If we have an assignment
            if line['expr']['nodeType'] == 'Expr_Assign':

                # Case where we have a variable on the left
                if line['expr']['var']['nodeType'] == 'Expr_Variable':
                    left = '$'+str(line['expr']['var']['name'])
                    #lst_global += [left]
                    lst_put  += [left]
                    # Case where there is a variable on the right
                    if line['expr']['expr']['nodeType'] == 'Expr_Variable':
                        right = '$'+str(line['expr']['expr']['name'])
                        #lst_global += [right]
                        lst_put += [right]
                    # Case where there is a function on the right
                    elif line['expr']['expr']['nodeType'] == 'Expr_FuncCall':
                        right = str(line['expr']['expr']['name']['parts'][0])
                        #lst_global += [right]
                        lst_put += [right]
                        #explore the functions arguments
                        for node in line['expr']['expr']['args']:
                            explore_args_2(node, right)

                    # Case where there is a binary operation on the right
                    elif line['expr']['expr']['nodeType'] == 'Expr_BinaryOp_Plus':
                        explore_args_2(line['expr']['expr'], left)

            # If we have a function call
            elif line['expr']['nodeType'] == 'Expr_FuncCall':
                funcName = str(line['expr']['name']['parts'][0])
                #lst_global += [funcName]
                lst_put += [funcName]
                # explore the functions arguments
                for node in line['expr']['args']:
                    explore_args_2(node, funcName)

        return lst_put
# Iterating through every line in the ast

""" print(nodes)
print(graph)
print(uninitiated_nodes)

print("node_list ", node_list)
print("graph_list ", graph_list)
print("uninitiated_nodes ", uninitiated_nodes)

 """

for line in sliceAST:

    if line['nodeType'] != 'Stmt_If':
    #print("lst_put", find_nodes(line, lst_global))
        find_nodes(line, lst_global)

    if line['nodeType'] == 'Stmt_If':
        lst_global += ["IF"]
        find_nodes(line['stmts'][0], lst_global)
        lst_global += ["ENDIF"]

    if 'else' in line and line['else']['nodeType'] ==  'Stmt_Else':
        lst_global += ['ELSE']
        find_nodes( line['else']['stmts'][0], lst_global)
        lst_global+= ['ENDELSE']

    if line['nodeType'] == 'Stmt_While':
        lst_global += ["WHILE"]

        #print(line['stmts'][0])
        for el in line['stmts']:
            find_nodes(el, lst_global)
        
        lst_global += ["ENDWHILE"]

        
#print('limit = ', limit_cond_vars())
#print("lst_before_cond", lst_before_cond)
#print("lst_global", lst_global)



def get_vars_before_cond(lst_all_vars):
    l_before = []
    #print(lst_all_vars)

    if 'IF' in lst_global:
        i = 0

        while lst_all_vars[i] != 'IF':
            if lst_all_vars[i] not in l_before:
                l_before += [lst_all_vars[i]]
            
            i+=1
    else:
        i=0

        while lst_all_vars[i] != 'WHILE':
            if lst_all_vars[i] not in l_before:
                l_before += [lst_all_vars[i]]
            i+=1
        i=0

    #print("l_before",l_before)
    return l_before
#get_vars_before_cond(lst_global)


def get_vars_inside_blck_cond(lst_all_vars):

    index_lst = []
    if 'IF' in lst_global:
        for i in range(len(lst_all_vars)):
            if lst_all_vars[i] == 'IF':
                index_lst += [i]
            if lst_all_vars[i] == 'ENDIF':
                index_lst += [i]
    else:
        for i in range(len(lst_all_vars)):
            if lst_all_vars[i] == 'WHILE':
                index_lst += [i]
            if lst_all_vars[i] == 'ENDWHILE':
                index_lst += [i]

    #print("index_lst", index_lst)

    #pode rebentar aqui
    lst_vars_inisde_cond = []
    for i in range(index_lst[0] + 1, index_lst[1]):
        lst_vars_inisde_cond += [lst_all_vars[i]]
    
    #print("lst_vars_inisde_cond", lst_vars_inisde_cond)

    return lst_vars_inisde_cond

#get_vars_inside_blck_cond(lst_global)


def check_vars_cond_in_before(lst_vrs_before_cond, lst_vars_inside_cond):
    set_var_init = set(lst_vrs_before_cond) & set(lst_vars_inside_cond)
    #print(list(set_var_init))

    return list(set_var_init)
#check_vars_cond_in_before(get_vars_before_cond(lst_global), get_vars_inside_cond())


def get_vars_in_cond_n_init(lst_vrs_insd_cnd, lst_vars_cond_in_before):
    lst_cond_n_init = []
    for el in lst_vrs_insd_cnd:
        if el not in lst_vars_cond_in_before:
            lst_cond_n_init += [el]

    #print("lst_cond_n_init = ", lst_cond_n_init)
    return lst_cond_n_init

#print("lst_global", (lst_global))


def choose_lst_to_put(l_global):
    
    l_choices = []
    if 'if' in lst_global:
        for i in range(len(l_global)):
            if l_global[i] == 'IF':
                l_choices += [[i]]
            
            if 'ENDELSE' in l_global:
                if l_global[i] == "ENDELSE":
                    l_choices += [[i]]
            
            elif 'ENDELSE' not in l_global:
                if l_global[i] == "ENDIF":
                    l_choices += [[i]]

    else:
        for i in range(len(l_global)):
            if l_global[i] == 'WHILE':
                l_choices += [[i]]
            
            if 'ENDWHILE' in l_global:
                if l_global[i] == "ENDWHILE":
                    l_choices += [[i]]
            
            
    #print("l_choices", l_choices)
    if 'IF' in lst_global:
        if l_choices[0] != [0] and l_choices[1] != [len(l_choices) -1 ] :
            index_cond = 1
    else:
        index_cond = 0
    #print(index_cond)
    return index_cond

#choose_lst_to_put(lst_global)

def create_new_arcs(graph_list, index_cond, lst_inside_cond, l_inside_cond):
   
    for el in lst_inside_cond:
        for ele in l_inside_cond:
            if el not in graph_list[index_cond]:
                graph_list[index_cond][el] = [ele]
                node_list[index_cond] += [el]
            elif el in graph_list[index_cond]:
                if ele not in graph_list[index_cond][el]:
                    graph_list[index_cond][el].append(ele)
    
    #print("node_list = ", node_list)
    #print("graph_list = ", graph_list)
    return graph_list

#create_new_arcs(graph_list, choose_lst_to_put(lst_global), get_vars_inside_cond(),
#                        get_vars_inside_blck_cond(lst_global))

def put_node_cond_n_init_in_uninit_lst_nds(lst_vars_in_cond_n_init, index_cond):
    #print(index_cond)
    
    for el in lst_vars_in_cond_n_init:
        if el not in uninitiated_list[index_cond]:
            uninitiated_list[index_cond].append(el)
    #print("uninitiated_nodes = ", uninitiated_list)


def implicit_flow_choose():

    isImplicitFlow = False

    for vuln in vuln_lst:
        if vuln[-1] == "yes":
            isImplicitFlow = True
    
    if 'IF' in lst_global and isImplicitFlow:
        create_new_arcs(graph_list, choose_lst_to_put(lst_global), get_vars_inside_cond(),
                        get_vars_inside_blck_cond(lst_global))

        put_node_cond_n_init_in_uninit_lst_nds(
            get_vars_in_cond_n_init(get_vars_inside_cond(), \
            check_vars_cond_in_before(get_vars_before_cond(lst_global), get_vars_inside_cond())),
            choose_lst_to_put(lst_global)
            )


        """ print("graph_list = ", graph_list)
        print("uninitiated_list = ", uninitiated_list)
        print("node_list = ", node_list) """

    if 'WHILE' in lst_global and isImplicitFlow:
        create_new_arcs(graph_list, choose_lst_to_put(lst_global), get_vars_inside_cond(),
                        get_vars_inside_blck_cond(lst_global))

        put_node_cond_n_init_in_uninit_lst_nds(
            get_vars_in_cond_n_init(get_vars_inside_cond(), \
            check_vars_cond_in_before(get_vars_before_cond(lst_global), get_vars_inside_cond())),
            choose_lst_to_put(lst_global)
            )


implicit_flow_choose()

class dd_list(dict):
    def __missing__(self, k):
        r = self[k] = []
        return r


def join_new_srcs_vuln_lst(vuln_lst, new_src_lst):
    # print("vuln_lst", vuln_lst, "new_src_lst", new_src_lst)

    new_src_vuln_lst = [];
    src_vuln_lst = []
    for src in new_src_lst:
        for vuln in vuln_lst:
            # print(vuln)
            src_vuln_lst += [[vuln[0], [src], vuln[2], vuln[3]]]

    # print("new_src_vuln_lst", new_src_vuln_lst)

    new_src_vuln_lst = vuln_lst + src_vuln_lst
    # print("new_src_vuln_lst", new_src_vuln_lst)
    return new_src_vuln_lst


# print(join_new_srcs_vuln_lst(vuln_lst, uninitiated_list[0]))

def find_all_paths(graph, start, end, path=[]):
    path = path + [start]
    if start == end:
        return [path]
    paths = []
    newpaths = []
    for node in graph[start]:
        if path.count(node) < 2:
            newpaths = find_all_paths(graph, node, end, path)
        for newpath in newpaths:
            paths.append(newpath)

    return paths


# graph = list_to_graph(arcs_lst)
# print(graph)
# print("all_paths", find_all_paths(graph,'$a',"d"))


def find_all_src_sinks(all_srcs_vuln_lst, node_lst):


    all_vuln_lst = []
    for vuln in all_srcs_vuln_lst:
        # print("vuln", vuln)
        for src in vuln[1]:
            # print("src", src)
            for sink in vuln[3]:
                # print(src, sink)
                if vuln[2] == []:
                    # print("src", src, "sink", sink)
                    if src != sink and src in node_lst and sink in node_lst:
                        all_vuln_lst += [[vuln[0], src, [], sink]]

                else:
                    for sanit in vuln[2]:
                        # print("src", src, "sink", sink)
                        # print(src, sanit, sink)
                        if src != sink and src in node_lst and sink in node_lst:
                            all_vuln_lst += [[vuln[0], src, sanit, sink]]

    # print("all_vuln_lst", all_vuln_lst )
    return all_vuln_lst


# print(find_all_src_sinks(join_new_srcs_vuln_lst(vuln_lst, uninitiated_list[0]), node_list[0] ))


def find_all_vuln_paths(graph, all_src_sink_lst):
    # print("all_src_sink_lst", all_src_sink_lst)
    all_vuln_paths_lst = []

    for src_sink in all_src_sink_lst:
        # print("all_paths",find_all_paths(graph, src_sink[1], src_sink[2]))
        # print(src_sink)
        all_vuln_paths_lst += [[src_sink[0], find_all_paths(graph, src_sink[1], src_sink[3])]]

    # print("all_vuln_paths_lst", all_vuln_paths_lst)
    return all_vuln_paths_lst


def is_src_sanit_sink_in_path(all_src_sink_paths, all_vuln_lst):

    d = dd_list()
    for vuln in vuln_lst:
        # print("arcs", arcs)
        d[vuln[0][0]].append((vuln[2]))

    lst_src_sanit_sink_in_path = []

    for src_sink_path in all_src_sink_paths:

        for vuln in all_vuln_lst:

            for paths in src_sink_path:

                for path in paths:

                    # verifica se a path tem a msm src e sink
                    if (path[0] == vuln[1] and path[-1] == vuln[-1]):

                        for el in d:

                            # print(list(set(path) & set(d[el][0])))
                            lst_set = list(set(path) & set(d[el][0]))
                            # print(vuln[0], [el])
                            if len(lst_set) == 0 and vuln[0] == [el]:
                                lst_src_sanit_sink_in_path += [[vuln[0], path[0], path[-1], "yes", []]]

                            if (len(lst_set) > 0) and vuln[0] == [el]:
                                lst_src_sanit_sink_in_path += [[vuln[0], path[0], path[-1], "no", [lst_set]]]

    lst_src_sanit_sink_in_path_dup = []
    # lst_src_sanit_sink_in_path_dup = list()

    [lst_src_sanit_sink_in_path_dup.append(item) for item in lst_src_sanit_sink_in_path if
     item not in lst_src_sanit_sink_in_path_dup]

    #print("lst_src_sanit_sink_in_path", lst_src_sanit_sink_in_path)
    #print("lst_src_sanit_sink_in_path", lst_src_sanit_sink_in_path_dup, '\n')
    return lst_src_sanit_sink_in_path_dup

lst_final_dup = []
for i in range(len(node_list)):
    aux = is_src_sanit_sink_in_path(find_all_vuln_paths(graph_list[i],
            find_all_src_sinks(
                join_new_srcs_vuln_lst(vuln_lst, uninitiated_list[i]),
                node_list[i])),
            find_all_src_sinks(
                join_new_srcs_vuln_lst(vuln_lst,uninitiated_list[i]),
                node_list[i]))
    
    """ print(is_src_sanit_sink_in_path(find_all_vuln_paths(graph_list[i],
            find_all_src_sinks(
                join_new_srcs_vuln_lst(vuln_lst, uninitiated_list[i]),
                node_list[i])),
            find_all_src_sinks(
                join_new_srcs_vuln_lst(vuln_lst,uninitiated_list[i]),
                node_list[i]))) """

    
    lst_final_dup += aux

#print("lst final", lst_final_dup)

lst_final = []

for lst in lst_final_dup:
    if lst not in lst_final:
        lst_final.append(lst)

print("\n\nlst_final", lst_final) 


def format_lst(lst):
    new_lst = []
    for i in lst:
        new_lst.append([i[0][0], i[1], i[2], i[3], i[4]])
    return new_lst


def transform_lst(lst):
    new_lst = []
    for i in lst:
        if len(new_lst) == 0:
            # if len(i[4]) == 0:
            #     i[4] = [i[4]]
            new_lst.append(i)
        elif i[0] == new_lst[len(new_lst) - 1][0] and i[1] == new_lst[len(new_lst) - 1][1] and i[2] == \
                new_lst[len(new_lst) - 1][2]:
            if i[3] != new_lst[len(new_lst) - 1][3]:
                new_lst[len(new_lst) - 1][3] = 'yes'
            if len(i[4]) > 0:
                # print(new_lst[len(new_lst) - 1])
                # print(new_lst[len(new_lst) - 1][4])
                new_lst[len(new_lst) - 1][4].append(i[4][0])
        else:
            new_lst.append(i)      
    return new_lst

# Change "b" to whatever name the var has
# print(l)
a = transform_lst(format_lst(lst_final))

json_lst = []

for i in a:
    json_dict = dict.fromkeys(["vulnerability", "source", "sink", "unsanitized flows", "sanitized flows"])
    json_dict["vulnerability"] = i[0]
    json_dict["source"] = i[1]
    json_dict["sink"] = i[2]
    json_dict["unsanitized flows"] = i[3]
    json_dict["sanitized flows"] = i[4]

    json_lst = json_lst + [json_dict]

# print(json_lst)

json_object = json.dumps(json_lst, indent=4)

with open("output/" + sliceAST_path[11:-5] + ".output.json", "w") as outfile:
    outfile.write(json_object)
# Test tool
