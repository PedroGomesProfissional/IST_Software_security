# ssof22_23
SSof Project 2022-23

Para correr o programa: 
Por exemplo:
    python3 php-analyser.py slices_ast/8-loops-implicit.json patterns/8-loops-implicit.patterns.json 

