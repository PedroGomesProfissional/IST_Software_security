# Challenge `Short_Local_Read` writeup

- Vulnerability: What type of vulnerability is being exploited
  - Format strings
- Where: Where is the vulnerability present
  - Buffer
- Impact: What results of exploiting this vulnerability
  - Ler o que está dentro de um endereço

## Steps to reproduce

1. Pelas hints do challenge fiz fui alterando o n de "%n$s" até acertar no valor 7 e dar-me a flag

Payload final: python -c 'print "%7$s"' | ./bin



