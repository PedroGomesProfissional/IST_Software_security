# Challenge `Simple_Local_Read` writeup

- Vulnerability: What type of vulnerability is being exploited
  - Format Strings
- Where: Where is the vulnerability present
  - Buffer
- Impact: What results of exploiting this vulnerability
  - Permite ler o que está dentro de um endereço

## Steps to reproduce

1. Fui aumentando a valor de n '.%s'* n " até obter a flag

Payload final = python -c "print 'A'*4+'.%s'*10"
