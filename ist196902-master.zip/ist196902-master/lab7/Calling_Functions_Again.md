# Challenge `Calling_Functions_Again` writeup

- Vulnerability: What type of vulnerability is being exploited
  - Format Strings
- Where: Where is the vulnerability present
  - Buffer, read
- Impact: What results of exploiting this vulnerability
  - Chamar uma função

## Steps to reproduce

1. Eu queria redirecionar a chamada exit para a func win entao dividi o endereço win em 2 partes, cada parte para vai ser escrita num endereço diferente
2. Vour escrever a primeira parte no endereço 8 e a segunda no endereço 7
3. s.send(p32(0x804a01a)+p32(0x804a018)+b'%2044x%7$hn' + b'%31895x%8$hn')

[(POC)](Calling_Functions_Again.py)
