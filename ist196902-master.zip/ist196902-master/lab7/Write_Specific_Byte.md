# Challenge `Write_Specific_Byte` writeup

- Vulnerability: What type of vulnerability is being exploited
  - Format Strings
- Where: Where is the vulnerability present
  - Buffer
- Impact: What results of exploiting this vulnerability
  - Permite alterar a execução do programa

## Steps to reproduce


1. nr & 0xff000000 - neste caso com o operador and, o resultado para qualquer nr só é diferente de 0 para valores na mesma casa do 0xff, os demais vao ser sempre 0 quer seja 0 ou 1 (1 & 1 = 1)

2. o meu objetivo comecou por ser escrever 0xff000000 em decimal e subtrair 4 que corresponde ao %n
corri o programa e nao obtive resultado nr = 4278190076

3. Testei para nr's menores 427819007 42781900 e funcionou

Payload final: python -c 'print "\x44\xa0\x04\x08" + "%42781900d"+ "%7$n"'
