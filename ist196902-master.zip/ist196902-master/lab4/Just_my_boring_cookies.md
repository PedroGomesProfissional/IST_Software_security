# Challenge `Just_my_boring_cookies` writeup

- Vulnerability: What type of vulnerability is being exploited
  - XSS
- Where: Where is the vulnerability present
  - No campo Search
- Impact: What results of exploiting this vulnerability
  - Permite escrever scripts

## Steps to reproduce

1. Comecei por fazer um teste simples, para ver se a página era vulnerável a XSS, escrevendo um simples script: `<script>alert(1)</script>` pelo que apareceu um pop up, o que sugerio que esta página era vulnerável relativamente a este ataque. 
2. Escrevi um script que me dava diretamente a cookie num pop up `<script>alert(document.cookie)</script>`

