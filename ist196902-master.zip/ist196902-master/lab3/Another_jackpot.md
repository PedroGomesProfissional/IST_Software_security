# Challenge `Another_jackpot` writeup

- Vulnerability: What type of vulnerability is being exploited
  - weak input validation que permite fazer race condition attack
- Where: Where is the vulnerability present
  - `current_session = get_current_session()`
    `current_session.username = username
    `db.session.commit() `
  Guarda a sessão e o username antes de validar o input
- Impact: What results of exploiting this vulnerability
  - Consigo ter acesso à sessão admin e extrair o segredo (flag)

## Steps to reproduce

1. No desafio referia que a vulnerabilidade encontrava-se no login então fui ler o código do login
2. Ao ler o código do login é possível perceber que é feita uma validação se o username e a password existem
3. Em seguida surge esta linha de código `current_session = get_current_session()` que gera ou retorna uma cookie e que a coloca como a sessão atual
4. A linha a seguir `current_session.username = username` coloca o username introduzido na sessão atual, que pode ser por exemplo admin  
5. A sessão é colocada na base de dados `db.session.commit()` 
6. Existe aqui uma janela de oportunidade para aplicar race conditions, só após estas linhas é que vão ser feitas outras validações de input.
7. Em seguida pesquisei por `flag`, de modo a perceber como chegar à soluçao do desafio
8. Fui redirecionado para a função `jackpot`
9. Aqui é bastante simples de perceber que só se obtém a flag caso a sessão atual tenha como username, nada mais nada menos do que `'admin'`
10. O que logo me fez pensar no ponto 4, porque se de alguma forma conseguisse, enquanto estou na sessão com o utilizador admin, fazer um pedido para a diretoria `/jackpot`, conseguiria obter o segredo.
11. Foi o que fiz comecei por criar 2 scripts python visto que precisaria de programas a fazer coisas diferentes ao mesmo tempo
12. Um script pedia um token e guardava-o num ficheiro para enviar para o script2
13. Ainda neste primeiro script é necessário fazer vários pedidos POST ,para manter a janela de oportunidade aberta e em que no campo username, obrigatoriamente, era colocado a string admin e a password uma qualquer, visto que durante a janela de oportunidade a password não seria verificada
14. Enquanto o script1 executava, o script2 abria o ficheiro que contém o valor da cookie, colocava no dicinário de cookies e fazia um pedido get para a diretoria `/jackpot` com o campo de cookies preenchido, com a chave `'JTOKEN'` e o valor que abriu do ficheiro
15. Corria iterativamente até o script 2 econtrar uma string `"SSof{"` e aqui terminava o script2.


[(login.py)](login.py) [(jackpot.py)](jackpot.py)


