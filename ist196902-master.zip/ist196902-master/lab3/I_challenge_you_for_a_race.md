# Challenge `I_challenge_you_for_a_race` writeup

- Vulnerability: What type of vulnerability is being exploited
  - Race conditions attack - Time-of-check, time-of-use TOCTOU
- Where: Where is the vulnerability present
  - A vulnerabilidade acontece dentro janela de vulnerabilidade que está presente entre o `if(!access(file_to_read, R_OK))` e `fd = fopen(file_to_read, "r");` 
- Impact: What results of exploiting this vulnerability
  - Permite alterar o ficheiro onde as permissões são validadas por outro ficheiro que vai ser lido

## Steps to reproduce

1. Primeiro tive de perceber o que a função access faz, basicamente ela avalia se o UID real tem permissões para uma determinada tarefa, por exemplo, leitura
2. Como eu não tinha permissões root para abrir o ficheiro para leitura, `/challenge/flag` o que tive de fazer foi criar um novo ficheiro que eu tivesse acesso a todas as permissões e fazer um `symbolic link` de um ficheiro /tmp/file_txt para gomito_ptr, por exemplo. 
3. Executo o programa com o ficheiro que foi apontado, gomito_ptr
4. Agora, dentro da janela de oportunidade, vou mudar o ficheiro que vai ser lido, para isso apago o link prévio e crio um novo link `ln -fs /challenge/flag gomito_ptr`, que no script está a ser executado nas traseiras, então permite-me ler o conteúdo dentro do ficheiro flag.
5. Corri o meu script pela linha de comandos, não criei nenhum ficheiro bash.

[(I_challenge_you_for_a_race.txt)](I_challenge_you_for_a_race.txt)
