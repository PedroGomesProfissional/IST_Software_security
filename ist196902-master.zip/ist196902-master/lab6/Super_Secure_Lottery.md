# Challenge `Super_Secure_Lottery` writeup

- Vulnerability: What type of vulnerability is being exploited
  - Buffer overflow
- Where: Where is the vulnerability present
  - func memcmp
- Impact: What results of exploiting this vulnerability
  - Overwrite a variavel guess 

## Steps to reproduce

1. Comecei por fazer um teste básico, submeti 64 chars e funcionou, porque consegui fazer overwrite do buffer guess

