# Challenge `Simple_Overflow` writeup

- Vulnerability: What type of vulnerability is being exploited
  - Buffer overflow
- Where: Where is the vulnerability present
  - Função gets
- Impact: What results of exploiting this vulnerability
  - Modificar o valor de uma variavel

## Steps to reproduce

1. Ao olha para este desafio percebi que o que pretendemos fazer é alterar o valor da var test então para isso vou ter de dar overwrite à var test, através do preenchimento do buffer e submeter o char diferente de 0
Payload final: python -c "print 'A'*128+'\x01'"| ./simple - 128 chars para preencher o buffer todo + o char '1' para escrever na var test

