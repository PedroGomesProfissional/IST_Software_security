# Challenge `Match_an_Exact_Value` writeup

- Vulnerability: What type of vulnerability is being exploited
  - Buffer overflow
- Where: Where is the vulnerability present
  - Funcao gets
- Impact: What results of exploiting this vulnerability
  - Modificar um variavel
- NOTE: Any other observation

## Steps to reproduce

1. Queremos fazer overwrite da variavel `test` e escrever o valor do endereço para que a igualdade seja satisfeita
2. Para isso fazer python -c "print 'A'*64+'\x64\x63\x62\x61'" - 64 chars para preencher o buffer + address em little endian

