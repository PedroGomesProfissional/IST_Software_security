# Challenge `python_requests_again` writeup

- Vulnerability: What type of vulnerability is being exploited
  - Client-Side Cookie Tampering
- Where: Where is the vulnerability present
  - Na cookie remaining_tries - Cookie “remaining_tries” does not have a proper “SameSite” attribute value (mensagem do browser)
- Impact: What results of exploiting this vulnerability
  - Permite modificar o valor da cookie que limitava o número de requests possíveis.

## Steps to reproduce
1. Comecei por importar a biblioteca de python requests
2. Montei uma sessão com python requests por forma a interagir com o sevidor sempre na mesma sessão
3. O problema é que só conseguia fazer 2 get requests até obter um erro, isto impossibilitava-me de seguir o mesmo método que usei para resolver o exercício `python_requests`
4. Ao analisar as cookies que obtinha pelo método GET reparei que o valor da `Cookie remaining_tries` mudava, neste caso, decrescia.
5. Percebi então que podia alterar o valor desta chave (de dicionário) para um número maior, coloquei a 30
6. Após feito o ponto 5 reutilizei o código do exercício anterior que extraia os dígitos do texto, comparava a igualdade (das listas) e envia um pedido ao servidor com a string ou `finish` ou `more`
[(POC)](python_requests_again.py)
