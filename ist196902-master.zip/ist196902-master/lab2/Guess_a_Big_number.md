# Challenge `Guess a Big Number` writeup

- Vulnerability: What type of vulnerability is being exploited
  - Corri um scan com o ZAP e extrai uma vulnerabilidade chamada `Cookie No HttpOnly Flag`
- Where: Where is the vulnerability present
  -`/guess/number` endpoint_
- Impact: What results of exploiting this vulnerability
  - Permite encontrar um servidor através de várias tentativas

## Steps to reproduce

1. No browser comecei por enviar um número arbitrário menor que 100000 e obtive como resposta "Higher"
2. Fiz o mesmo para 100001 onde recebi uma resposta de "Lower"
3. Percebi entao que com as respostas do servidor é possível ter uma nocão da proximidade do valor. Posto isto escrevi um script em que a cada iteracao decrementa 1000 de uma variavel inicialmente colocada a 100000 até encontrar a resposta lower, apartir daí incrementa 1 e vê se a mensagematé obter a flag. 
4- Incrementar 1 até ao valor correto demora mais no entanto dá-me certezas de que vou atingir o valor.


[(POC)](Guess_a_BIG_Number.py)
