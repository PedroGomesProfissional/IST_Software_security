import requests

SERVER = 'http://mustard.stt.rnl.tecnico.ulisboa.pt:22053/more'


##### WITH SESSIONS
# start session
session = requests.session()

## Similar for other methods
r = session.get(SERVER) 
all_cookies = requests.utils.dict_from_cookiejar(session.cookies)
#print(r.text)

i=0
target =  1
current = 1
lst_check_target = []
lst_check_current = []
while (i<60):
    r = session.get(SERVER)
    #print(f'r : {r.cookies}'); print(r.text)
    split_list = r.text.split()
    #print(split_list)
    for c in split_list[6]:
        if c.isdigit():
            lst_check_target.append(int(c))
    #print(lst_check_target)

    for c in split_list[-1]:
        if c.isdigit():
            lst_check_current.append(int(c))
    #print(lst_check_current)
    if(lst_check_current == lst_check_target):
        r_fini = session.get('http://mustard.stt.rnl.tecnico.ulisboa.pt:22053/finish')
        print(r_fini.text)
        break
   
    lst_check_target = []
    lst_check_current = []
    i+=1
    



