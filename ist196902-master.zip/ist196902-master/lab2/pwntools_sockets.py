#SSof{Scripting_over_sockets}

from pwn import *

"""
IN: str - to extract the digits
OUT: list - with digt's number
"""
def get_digit(extract_digit : str):
    lst_digit = []
    for c in str(extract_digit):
        if c.isdigit():
            lst_digit.append(c)
    return lst_digit
            
"""
IN: list with phrases
OUT: list with numbers
"""
def search_numbers(lst_to_find_numbers):
    digit_lst = []

    for ele in lst_to_find_numbers[6:]:
        for c in str(ele):
            if (c.isdigit()):
                digit_lst+=[c]
           
    #print("digit_lst", digit_lst)
    return digit_lst

SERVER = 'mustard.stt.rnl.tecnico.ulisboa.pt'
PORT = 22055
#context.log_level = 'DEBUG'

conn = remote(SERVER,PORT)

print(conn.recvline())
target_lst = conn.recvline()
target_split= target_lst.split()
target_lst_numbers= get_digit(target_split[-1])
#print("target number= ", target_lst_numbers)

data_rcv= conn.recvuntil(b'- Or are you done (type FINISH)?\n')
print("data_rcv outside loop: ", data_rcv)
conn.sendline(b'MORE')

i=0
n=25
while (i<n):

    data_rcv= conn.recvuntil(b'- Or are you done (type FINISH)?\n')
    #print("Received: ", data_rcv); print('\n')

    data_rcv_splt= data_rcv.split()
    #print(data_rcv_splt)
        
    current_lst = search_numbers(data_rcv_splt)

    if (current_lst == target_lst_numbers):
        conn.sendline(b"FINISH")
        break

    else:
        conn.sendline(b'MORE')

    i+=1 

conn.interactive()

conn.close()
