# Challenge `python_requests` writeup

- Vulnerability: What type of vulnerability is being exploited
  - Corri um scan com o ZAP e extrai uma vulnerabilidade chamada `Cookie No HttpOnly Flag`
- Where: Where is the vulnerability present
  - Na cookie `user` - Cookie “user” does not have a proper “SameSite” attribute value
- Impact: What results of exploiting this vulnerability
  - permite obter valores para os números current e target, até estes ficarem iguais, através de enumeração.

## Steps to reproduce
1. Comecei por importar a biblioteca de python requests
2. Montei uma sessão com python requests por forma a interagir com o sevidor sempre na mesma sessão
3. Após vários gets é possível ver que existe uma tendência para o número dado por `Here you have:` decrescer e o número `your current value` se aproximar do `target number`
4. Posto isto percebi então que precisaria de fazer vários get requests e quando o target e current number fossem iguais enviar um request para a diretoria /finish.
5. O que fiz foi fazer um script que iterativamente fazia vários pedidos ao servidor. Ao receber a resposta fazia um split do texto html, pela string espaço. Na lista `splitted` os números estavam sempre na mesma posição, iterei por forma a extrair apenas os digitos e coloquei em listas diferentes os digitos de target e current, finalmente comprei se as duas listas eram iguais.
6. Caso diferissem seguia para a iteração seguinte
7. No caso de serem iguais enviava o pedido get para a diretoria finish e depois recebia a flag 

[(POC)](python_requests.py)
