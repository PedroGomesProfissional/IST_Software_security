import requests

SERVER = 'http://mustard.stt.rnl.tecnico.ulisboa.pt:22052'

session = requests.session()
r = session.get(SERVER)
print(r.text)

number = 100001
while 1:
    SERVER_str = "{SERVER}/number/{number}"
    SERVER_str = SERVER_str.format(SERVER=SERVER, number = number)
    r = session.get(SERVER_str)
    print(r.text)
    if ( r.text == "<h1>Lower!</h1>"):
        print(SERVER_str)
        number-=1000
    elif (r.text == "<h1>Higher!</h1>" ):
        print(SERVER_str)
        number += 1
    elif (r.text != "<h1>Higher!</h1>" ):
        break
   
