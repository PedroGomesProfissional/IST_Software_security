# Challenge `pwntools_sockets` writeup

- Vulnerability: What type of vulnerability is being exploited
  - socket scripting
- Where: Where is the vulnerability present
  - scripting
- Impact: What results of exploiting this vulnerability
  - Permite enviar e receber mensagens para o servidor remote e extrair um segredo (flag)

## Steps to reproduce

1. Conectei-me ao servidor remoto na porta dada
2. Criei um loop que recebia as linhas até `- Or are you done (type FINISH)?\n`
3. Seguidamente avaliava se os números current e target das linhas recebidas eram iguais
4. Avaliava se os numeros current e target eram iguais e consante fossem ou não enviava, para o servidor, ou `FINISH` ou `MORE`
5. Tive um problema porque as 2 primeiras linhas eram diferentes de todas as outras então o que tive de fazer antes de criar o loop que recebia e enviava mensagens para o servidor, li as duas primeiras linhas e só depois fiz o loop. (Este problema deveu-se exclusivamente à forma como escrevi o código).
6. Após o ponto 4 caso os números diferissem enviava uma linha com a string `MORE`
7. caso contrário enviaria `FINISH`, terminaria o ciclo e receberia a flag

[(POC)](pwntools_sockets.py)
