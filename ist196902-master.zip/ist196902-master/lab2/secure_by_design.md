# Challenge `secure_by_design` writeup

- Vulnerability: What type of vulnerability is being exploited
  - Client-Side Cookie Tampering
- Where: Where is the vulnerability present
  - A vulnerabilidade encontra-se na cookie user
- Impact: What results of exploiting this vulnerability
  - Permite modificar o valor da cookie no lado do cliente e extrair a flag

## Steps to reproduce
1. Pelo browser vi que ao submeter uma string no form era gerada uma cookie user com o valor da mesma codificado em base64
2. Introduzi um nome aleatório no form e obtive uma mensagem `Unfortunately our page is still under construction for non-admin users.` que me sugeriu inserir a string `admin` que me redirecionou para uma página diferente, no entanto, a string que aparecia na cookie, encriptada em base64, não correspondia a admin (ao fazer decode). Aqui consegui perceber que era algo relacionado com a string admin.
3. Criei um script onde comecei por utilizar o método get para receber a informação do servidor
4. Utilizei o método post para preencher o formulário com uma string
5. Fiz encode da string admin para base64
6. Alterei o valor da cookie user na sessão, para a string encoded em base64
7. Apliquei o método get e extrai a flag


[(POC)](secure_by_design.py)
