# Challenge `Wow,_it_can't_be_more_juicy_than_this!` writeup

- Vulnerability: What type of vulnerability is being exploited
  - SQL Injection
- Where: Where is the vulnerability present
  - No campo search
- Impact: What results of exploiting this vulnerability
  - Ver/ter acesso a um post que não estava visível

## Steps to reproduce

1. O único campo que ainda não tinha tentado fazer algum tipo de SQL Injection foi o search então experimentei alguns testes para ver se era vulnerável, comecei com uma plica, depois `'--` sem sucesso, posteriormente, experimentei `'select` o que me deu uma erro de base de dados, então pude concluir que era possível injetar código SQL neste campo.
2. Obtive esta mensagem de erro `SELECT id, title, content FROM blog_post WHERE title LIKE '%'select%' OR content LIKE '%'select%'` pelas pistas do enunciado percebi que de alguma forma teria de fazer queries para encontrar algo que não estava visível.
3. Escrevi `'union select null, null, null --` para saber qual o número de colunas que é retornado. Apareceu um place holder de um blog post (fui acrescentado null's até deixar de dar erro)
4. Escrevi `'union select null, 'a', 'a' --` para saber que campos em que é possível escrever (tentei a escrita nos 3 campos)
5. Escrevi `'union select null, tbl_name, null from sqlite_master--` para saber o nome de todas as colunas o que me apareceu um secret_blog_post (li a documentação do sqlite_master)
6. Escrevi `'union select null, a, null from secret_blog_post--` para saber se dava alguma mensagem de erro que me indicasse os campos corretos, pelo que obtive, `SELECT id, title, content FROM blog_post`
7. Por último escrevi `'union select null, title, content from secret_blog_post--` o que me deu a flag
 
