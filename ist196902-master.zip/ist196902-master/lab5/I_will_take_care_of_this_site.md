# Challenge `I_will_take_care_of_this_site` writeup

- Vulnerability: What type of vulnerability is being exploited
  - SQL Injection
- Where: Where is the vulnerability present
  - Página 'login' no campo Username 
- Impact: What results of exploiting this vulnerability
  - Permite ter acesso à conta do 'admin'

## Steps to reproduce

1. Comcei por testar se os campos de login eram vulnerávies a SQL injection submetendo uma plica no campo username, o que deu uma mensagem de erro 
2. `username = ''' AND password =` esta parte do erro foi a mais interessante porque posso submeter uma tautologia e colocar o resto dos campos, neste caso só a password, em comentário permitindo ignorar este campo. 
3. A tautologia que submeti no campo username foi `' OR 1=1--` o que me deu acesso à conta do admin diretamente
4. Fui ao perfil do admin e extrai a flag no campo `Bio`
