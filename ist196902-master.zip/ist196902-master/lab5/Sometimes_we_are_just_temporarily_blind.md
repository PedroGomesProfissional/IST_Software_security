# Challenge `Sometimes_we_are_just_temporarily_blind` writeup

- Vulnerability: What type of vulnerability is being exploited
  - Blind SQL Injection
- Where: Where is the vulnerability present
  - Campo search
- Impact: What results of exploiting this vulnerability
  - Descobrir informção contida em tables, colunas, que não estão visíveis.

## Steps to reproduce

1. Comecei por fazer uma pesquisar apenas com uma plica e obtive `Found 4 articles with search query ''--'`, reparo que existem 4 artigos
2. Percebi qual o tipo de mensagens que obtinha e ao submeter este código `'union select null, null, null from sqlite_master--` obtive uma mensagem `Found 5 articles with search query ''union select null, null, null from sqlite_master--'` o que significa que existem 5 artigos, também o número total de tables
3. O que pretendo é saber o nome da tabela, para isso vou precisar de saber o comprimento desta, visto que vou ter de aplicar o método brute force. Para extrair o comprimento fiz algumas tentativas e cheguei ao payload `'union select null, name, null from sqlite_master where length(tbl_name)=19--`. Fazer notar que utilizei os operadores '<' '>' para saber a que distância me encontrava do valor.
4. Vou fazer brute force para cada caracter pelas respetivas posições `'union select null, name, null from sqlite_master where substr(tbl_name,1,1)='a'--` retorn 4 artigos, no entanto para `substr(tbl_name,1,1)='s'--` retorna 5 artigos, esta é então a minha forma de saber se encontrei o caracter correto. Escrevi um program em python que encontra o caracter certo para uma dada posição
5. Obtive como `tbl_name` super_s_sof_secrets, no entanto não sei as colunas. Para descobrir colunas utilizei um porcesso análago comecei por saber qual o comprimento da coluna utilizando o seguinte código `'union select null, name, null from PRAGMA_TABLE_INFO('super_s_sof_secrets') where length(name)=6--`
6. Por forma a descobrir os caracteres de cada coluna utilizei o mesmo processo do ponto 4, `'union select null, name, null from PRAGMA_TABLE_INFO('super_s_sof_secrets') where substr(name,1,1)='a'--`
7. Reutilizei o código do ponto 4 e obtive `isdecret` depressa desmontei para id secret. Analisei o script e percebi que as letras 'i' e 's' correspondem ao primeiro caracter e 'd' e 'e' ao segundo caracter 'c' ao terceiro, portanto uma coluna é efetivamente secret
8. Agora é extrair a informção contida na coluna, para isso comecei por extrair o comprimento como no ponto 3 `'union select null, secret, null from super_s_sof_secrets where length(secret)=114--`
9. Por fim escrevi/reutilizei o código que escrevera acime e extrai a flag tendo por base `'union select null, secret, null from super_s_sof_secrets where substr(secret, 1, 1)='a'--`


[(Sometimes_we_are_just_temporarily_blind)](Sometimes_we_are_just_temporarily_blind.py)
