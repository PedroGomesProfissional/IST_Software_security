# Challenge `Money,_money,_money!` writeup

- Vulnerability: What type of vulnerability is being exploited
  - SQL Injection
- Where: Where is the vulnerability present
  - Na página profile no campo Bio
- Impact: What results of exploiting this vulnerability
  - Permite atualizar um campo que não está visível


## Steps to reproduce

1. Comcei por registar uma conta e fui à pagina 'profile'. No enunciado referia algo relativo aos tokens e read only pelo que eu pude inferir que podia tentar atualizar o valor do jackpot para zero  
2. Submeti uma plica no campo `Bio` para ver se o campo era vulnerável a SQL Injection e obti uma mensagem de erro `UPDATE user SET bio = ''teste' WHERE username =`
3. Pela mensagem de erro notei que poderia atualizar o valor de outros campos, nomeadamente do jackpot_val, que obtive acesso na mensagem de erro do exercício passado, posto isto, executei o seguinte payload `', jackpot_val = '0`
4. Até conseguir o payload certo tive de perceber que plicas já se encontravam na mensagem de erro e as que eu necessitava de acrescentar.
